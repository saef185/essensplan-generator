
import streamlit as st
import pandas as pd
import random

st.title("🥗 Essensplan Generator – vegetarisch/vegan & saisonal")

uploaded_file = st.file_uploader("Lade deine Excel- oder CSV-Datei mit den Gerichten hoch")

def klassifiziere_gericht(name):
    vegan_keywords = [
        "vegan", "linsen", "tofu", "soja", "kichererbse", "falafel",
        "hummus", "gemüse", "rote bete", "bolognese (vegan)", "vegane",
        "süßkartoffel", "bulgur", "quinoa", "dal", "curry", "suppe"
    ]
    if any(word in name.lower() for word in vegan_keywords):
        return "vegan"
    return "vegetarisch"

def ist_sommer_gericht(name):
    sommer_keywords = [
        "salat", "tomate", "zucchini", "gurke", "salsa", "minze",
        "beere", "quark", "wrap", "karotte", "rucola", "süßkartoffel",
        "grill", "ofengemüse", "gazpacho", "tabouleh", "bowl", "gratin", "lasagne"
    ]
    winter_keywords = ["eintopf", "gulasch", "auflauf", "braten", "suppe", "schmarrn"]
    n = name.lower()
    if any(w in n for w in sommer_keywords):
        return "ja"
    if any(w in n for w in winter_keywords):
        return "nein"
    return "ja"

def wochenplan_generator(df, anzahl=7):
    df_sel = df[(df["Kategorie"] == "vegan") & (df["Saison_Juli"] == "ja")]
    if len(df_sel) < anzahl:
        df_vegan_rest = df[(df["Kategorie"] == "vegan") & (df["Saison_Juli"] == "nein")]
        df_sel = pd.concat([df_sel, df_vegan_rest])
    if len(df_sel) < anzahl:
        df_veg_sommer = df[(df["Kategorie"] == "vegetarisch") & (df["Saison_Juli"] == "ja")]
        df_sel = pd.concat([df_sel, df_veg_sommer])
    if len(df_sel) < anzahl:
        df_veg_rest = df[(df["Kategorie"] == "vegetarisch") & (df["Saison_Juli"] == "nein")]
        df_sel = pd.concat([df_sel, df_veg_rest])
    df_sel = df_sel.drop_duplicates("Essen")
    plan = df_sel.sample(n=anzahl, random_state=random.randint(1, 10000)).reset_index(drop=True)
    return plan

if uploaded_file:
    if uploaded_file.name.endswith(".csv"):
        df = pd.read_csv(uploaded_file)
    else:
        df = pd.read_excel(uploaded_file)
    if "Essen" not in df.columns:
        st.error("Die Datei braucht mindestens eine Spalte namens 'Essen'.")
    else:
        df["Kategorie"] = df["Essen"].apply(klassifiziere_gericht)
        df["Saison_Juli"] = df["Essen"].apply(ist_sommer_gericht)
        st.subheader("Alle Gerichte (automatisch klassifiziert)")
        st.dataframe(df)

        if st.button("Erzeuge Wochenplan"):
            plan = wochenplan_generator(df, 7)
            st.subheader("Vorschlag für deinen Wochenplan (7 Tage)")
            st.dataframe(plan)

            csv = plan.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="Wochenplan als CSV herunterladen",
                data=csv,
                file_name='Wochenplan.csv',
                mime='text/csv'
            )
