# Essensplan Generator

Einfaches Streamlit-Tool zur automatischen Erstellung eines vegetarisch/veganen Wochen-Essensplans.

## Nutzung
1. Starte mit `streamlit run app.py`
2. Lade eine Excel- oder CSV-Datei hoch (mindestens eine Spalte 'Essen').
3. Klicke auf "Erzeuge Wochenplan", um 7 passende Gerichte zu generieren.

## Deployment-Tipp
Dieses Projekt lässt sich direkt bei [Streamlit Cloud](https://streamlit.io/cloud) deployen oder lokal ausführen.